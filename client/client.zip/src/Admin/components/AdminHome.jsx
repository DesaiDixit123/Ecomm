export default function AdminHome() {
    return(
        <>
<h1>AdminHome Page</h1>
    </>
    )
}